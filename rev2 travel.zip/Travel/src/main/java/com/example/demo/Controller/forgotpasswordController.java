package com.example.demo.Controller;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.forgotpasswordModel;
import com.example.demo.Service.forgotpasswordService;

@RestController
public class forgotpasswordController 
{

	@Autowired 
	private forgotpasswordService fs;
	@GetMapping("/forpass")
	
	public ArrayList<forgotpasswordModel> getDet1()
	{
		return fs.getDet1();
	}
}
