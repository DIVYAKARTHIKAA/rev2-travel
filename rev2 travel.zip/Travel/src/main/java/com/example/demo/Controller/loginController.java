package com.example.demo.Controller;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.loginModel;
import com.example.demo.Service.loginService;

@RestController
public class loginController {

	@Autowired
	private loginService ls;
	@GetMapping("/login")
	public ArrayList<loginModel> getDetails()
	{
		return ls.getDetails();
	}
}
