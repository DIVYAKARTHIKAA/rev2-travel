package com.example.demo.Controller;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.signupModel;
import com.example.demo.Service.signupService;

@RestController
public class signupController {
@Autowired

private signupService s;
@GetMapping("/signup")
public ArrayList<signupModel> getDet3() 
{
	return s.getDet3();
}
}
