package com.example.demo.Controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.traveldetModel;
import com.example.demo.Service.traveldetService;

@RestController
public class traveldetController {
@Autowired
private traveldetService ts;
@GetMapping("/tradet")

	public ArrayList<traveldetModel>getDet4() 
	{
		return ts.getDet4();
	}
}
