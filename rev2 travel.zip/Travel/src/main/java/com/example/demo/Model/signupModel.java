package com.example.demo.Model;



public class signupModel {
		
		
		private String username;
		private String email;
		private long phoneno;
		private String address;
		private String password;
		
		
		public signupModel(String username, String email, long phoneno, String address, String password) {
			super();
			this.username = username;
			this.email = email;
			this.phoneno = phoneno;
			this.address = address;
			this.password = password;
		}


		public String getUsername() {
			return username;
		}


		public void setUsername(String username) {
			this.username = username;
		}


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}


		public long getPhoneno() {
			return phoneno;
		}


		public void setPhoneno(long phoneno) {
			this.phoneno = phoneno;
		}


		public String getAddress() {
			return address;
		}


		public void setAddress(String address) {
			this.address = address;
		}


		public String getPassword() {
			return password;
		}


		public void setPassword(String password) {
			this.password = password;
		}


		@Override
		public String toString() {
			return "signupModel [username=" + username + ", email=" + email + ", phoneno=" + phoneno + ", address="
					+ address + ", password=" + password + "]";
		}
}	
		
