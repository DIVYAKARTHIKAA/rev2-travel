package com.example.demo.Service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.example.demo.Model.forgotpasswordModel;

@Service
public class forgotpasswordService implements forgotpasswordServiceint {

	public static ArrayList<forgotpasswordModel> ls1=new ArrayList<>();
	static
	{
		forgotpasswordModel fp=new forgotpasswordModel("Radha","Radha123@gmail.com","radha@123","radha@123");
		ls1.add(fp);
	}
	@Override
	public ArrayList<forgotpasswordModel> getDet1() {
		// TODO Auto-generated method stub
		return ls1;
	}
	
	
	

}
