package com.example.demo.Service;

import java.util.ArrayList;

import com.example.demo.Model.forgotpasswordModel;


public interface forgotpasswordServiceint 
{
	public ArrayList<forgotpasswordModel> getDet1();
}
