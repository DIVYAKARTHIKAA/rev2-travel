package com.example.demo.Service;

import java.util.ArrayList;


import org.springframework.stereotype.Service;

import com.example.demo.Model.loginModel;

@Service
public class loginService implements loginServiceint 
{
	private static ArrayList<loginModel> ls2=new ArrayList<>();
	static 
	{
		loginModel lm=new loginModel("Sara123@gmail.com","sara@123");
		ls2.add(lm);
	}
	
	@Override
	public ArrayList<loginModel> getDetails() {
		// TODO Auto-generated method stub
		return ls2;
	}
	
	
	
}
