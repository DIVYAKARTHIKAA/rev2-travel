package com.example.demo.Service;

import java.util.ArrayList;

import com.example.demo.Model.loginModel;

public interface loginServiceint 
{
	public ArrayList<loginModel> getDetails();
}
