package com.example.demo.Service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.example.demo.Model.signupModel;

@Service
public class signupService implements signupServiceint {

	private static ArrayList<signupModel> ls3=new ArrayList<>();
	static 
	{
		signupModel sm=new signupModel("Radha","Radha154@gmail.com",987943212,"167,Anna nagar,chennai-12","Radha@123");
		ls3.add(sm);
	}
	@Override
	public ArrayList<signupModel> getDet3() {
		// TODO Auto-generated method stub
		return ls3;
	}
	
	
	
	
	
	
	
}

