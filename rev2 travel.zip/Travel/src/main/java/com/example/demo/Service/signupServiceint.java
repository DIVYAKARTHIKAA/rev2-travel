package com.example.demo.Service;

import java.util.ArrayList;

import com.example.demo.Model.signupModel;

public interface signupServiceint {
	public ArrayList<signupModel> getDet3();
}
