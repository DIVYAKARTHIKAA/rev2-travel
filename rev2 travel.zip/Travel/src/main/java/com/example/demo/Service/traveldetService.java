package com.example.demo.Service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.example.demo.Model.traveldetModel;

@Service

public class traveldetService implements traveldetServiceint {

	private static ArrayList<traveldetModel> ls4=new ArrayList<>();
	static 
	{
		traveldetModel tdm=new traveldetModel(1,"Coimbatore","Chennai","Rama","1000");
		ls4.add(tdm);
	}
	
	@Override
	public ArrayList<traveldetModel> getDet4() {
		// TODO Auto-generated method stub
		return ls4;
	}
	
	
	
}
