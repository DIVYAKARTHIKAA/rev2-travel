package com.example.demo.Service;


import java.util.ArrayList;

import com.example.demo.Model.traveldetModel;

public interface traveldetServiceint 
{
	public ArrayList<traveldetModel> getDet4();
}
